function setup() {
  createCanvas(400, 400);
  colorMode(RGB, 255, 255, 255, 1);
}

function draw() {
  background(20);
  space();
  earth();
  balloon();
  frameRate(0.01666);
}
function earth() {
  fill(0,100,200);
  noStroke();
  ellipse(80,400,400,400);
  fill(0,200,100);
  stroke(0,200,100);
  strokeWeight(1);
  curve(80,200,198,238,270,338,270,462);
  beginShape();
  vertex(198,238);
  vertex(270,338);
  vertex(190, 280);
  vertex(230, 300);
  endShape();
  beginShape();
  vertex(59,340);
  vertex(160,360);
  vertex(200, 400);
  vertex(-1, 400);
  endShape();
  noStroke();
  triangle(-10,280,60,340,0,400);  
  fill(0,100,200);
  stroke(250);
  fill(250);
  curve(142,210,80,200,18,210,-38,238);
  curve(0,200,18,210,80,200,100,100);
  noFill();
  stroke(255,255,255,0.2);
  strokeWeight(20);
  ellipse(80,400,380,380);
  fill(100,100,100,0.2);
  noStroke();
  ellipse(40,400,260,260);
  fill(0,0,0,0.2);
  noStroke();
  ellipse(20,400,200,100);
  fill(250,250,250,0.7);
  ellipse(50,315,50,20);
  ellipse(20,300,100,30);
  ellipse(150,330,64,17);
  ellipse(200,340,76,23);
}
function balloon() {
  noStroke();
  fill(230, 200, 240);
  rotate(-0.15);
  ellipse(270, 70, 300, 350);
  rotate(0.15);
  beginShape();
  vertex(210, 180);
  vertex(240, 230);
  vertex(360, 220);
  vertex(374, 168);
  vertex(210, 180);
  endShape();
  strokeWeight(3);
  stroke(100);
  line(260, 325, 240, 230);
  line(360, 315, 360, 220);
  fill(100, 50, 20);
  stroke(120,65,30);
  strokeWeight(20);
  strokeJoin(ROUND);
  beginShape();
  vertex(277, 380);
  vertex(260, 325);
  vertex(360, 315);
  vertex(354, 372);
  vertex(277, 380);
  endShape();
}
function space() {
  strokeWeight(20);
  stroke(255,255,255,0.1);
  line(400, 200, 400, 0);
  line(400, 200, 267, 0);
  line(400, 200, 133, 0);
  line(400, 200, 0, 0); // 
  line(400, 200, 0, 133);
  line(400, 200, 0, 267);
  line(400, 200, 0, 400);//
  line(400, 200, 133, 400);
  line(400, 200, 267, 400);
  line(400, 200, 400, 400);
  strokeWeight(10);
  stroke(255,240,100,0.3);
  fill(255);
  ellipse(400,200,50,50);
  line(400, 200, 400, 0);
  line(400, 200, 267, 0);
  line(400, 200, 133, 0);
  line(400, 200, 0, 0); // 
  line(400, 200, 0, 133);
  line(400, 200, 0, 267);
  line(400, 200, 0, 400);//
  line(400, 200, 133, 400);
  line(400, 200, 267, 400);
  line(400, 200, 400, 400);
  strokeWeight(3);
  fill(255);
  for (i = 0; i < 300; i++) {
    ellipse(random(0,400), random(0,400), 3, 3); //didnt want to draw the stars out myself, so I did this and slowed the frame rate to 1 per minute
  }
}