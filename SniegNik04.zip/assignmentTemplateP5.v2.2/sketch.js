let yMovement;
let xMovement;
let ballPosX;
let ballPosY;
function setup() {
  createCanvas(400, 400);
  yMovement=random(-15,15);
  xMovement=random(-15,15);
  ballPosX=random(0,400);
  ballPosY=random(0,400);
  ellipse(ballPosX, ballPosY, 20);
}
function draw() {
  background(220);
  if (xMovement <= 0) {
    for (i = 0;i>xMovement;i--){
      ballPosX -= 1;
    }
  } else {
    for (i = 0;i<xMovement;i++){
      ballPosX += 1;
    }
  }
  if (yMovement <= 0) {
    for (i = 0;i>yMovement;i--){
      ballPosY -= 1;  
    }
  } else {
    for (i = 0;i<yMovement;i++){
      ballPosY += 1;
    }
  }
  checkPos();
  ellipse(ballPosX, ballPosY, 20);
}
function checkPos() {
  if (ballPosX >=390) {
    if (xMovement <= 0) {xMovement = abs(xMovement)} else {
      xMovement = 0 - xMovement;
    }
  }
  if (ballPosX <= 10) {
    if (xMovement <= 0) {xMovement = abs(xMovement)} else {
      xMovement = 0 - xMovement;
    }
  }
  if (ballPosY >= 390) {
    if (yMovement <= 0) {yMovement = abs(yMovement)} else {
      yMovement = 0 - yMovement;
    }
  }
  if (ballPosY <= 10) {
    if (yMovement <= 0) {yMovement = abs(yMovement)} else {
      yMovement = 0 - yMovement;
    }
  }
}