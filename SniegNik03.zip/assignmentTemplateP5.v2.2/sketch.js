let fishx = [375, 50, 225, 200, 350, 150, 325, 25, 75, 175, 275, 125, 250, 400, 100, 300];
let fishy = [50, 225, 200, 350, 150, 325, 25, 75, 175, 275, 125, 250, 400, 100, 300, 375];
let playerSize = 25; 
function setup() {
  createCanvas(400, 400);
  frameRate(20);
}
function draw() {
  background(110);
  colorMode(RGB, 255,255,255,1);
  fill(100,100,200);
  stroke(100);
  ellipse(mouseX,mouseY, playerSize);
  let trailSize = sqrt(playerSize);
  fill(100,100,200);
  stroke(255);
  ellipse(pmouseX,pmouseY,trailSize);
  fill(100,100,200);
  stroke(0);
  line(mouseX,mouseY,pmouseX,pmouseY);
  ellipse(pmouseX,pmouseY,sqrt(trailSize));
  fill(200,100,100);
  fishMove();
}
function fishMove() {
  for (let i = 0; i < 15; i++) {
    if (dist(fishx[i] , fishy[i],mouseX,mouseY) <= playerSize/2) {
      fishy[i] = 15000; 
      playerSize += 5;
    } else {
      fishx[i] -= 7.5;
      ellipse(fishx[i] ,fishy[i] ,5);
    }
    if (fishx[i] <= 0) {
      fishx[i] = 400;
    }
  }
}